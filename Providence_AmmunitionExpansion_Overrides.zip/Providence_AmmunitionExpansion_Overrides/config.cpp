class CfgPatches
{
	class Providence_AmmunitionExpansion_Overrides
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] =
		{
			"DZ_Weapons_Ammunition",
			"DZ_Weapons_Magazines",
			"AmmunitionExpansion"
		};
	};
};

class CfgAmmo
{
	class Bullet_Base;
	
	class Bullet_AE127x99: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_762";
		round="FxRound_762";
		spawnPileType="Ammo_AE127x99";
		hit=12;
		indirectHit=0;
		indirectHitRange=0;
		airLock=1;
		initSpeed=853;
		typicalSpeed=853;
		airFriction=-0.00060000003;
		caliber=1.7;
		deflecting=10;
		damageBarrel=500;
		damageBarrelDestroyed=500;
		weight=0.041999999;
		impactBehaviour=1;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=796;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=796;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE300: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_556";
		round="FxRound_556";
		spawnPileType="Ammo_AE300";
		hit=8;
		indirectHit=0;
		indirectHitRange=0;
		initSpeed=716;
		typicalSpeed=716;
		airFriction=-0.00157;
		caliber=0.64999998;
		deflecting=10;
		tracerScale=1;
		tracerStartTime=-1;
		tracerEndTime=1;
		nvgOnly=1;
		damageBarrel=250;
		damageBarrelDestroyed=250;
		weight=0.0071;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=122;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=122;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE338: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_762";
		round="FxRound_762";
		spawnPileType="Ammo_AE338";
		hit=12;
		indirectHit=0;
		indirectHitRange=0;
		airLock=1;
		initSpeed=900;
		typicalSpeed=900;
		airFriction=-0.00066000002;
		caliber=1.5;
		deflecting=10;
		damageBarrel=500;
		damageBarrelDestroyed=500;
		weight=0.0162;
		impactBehaviour=1;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=286;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=286;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE408: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_762";
		round="FxRound_762";
		spawnPileType="Ammo_AE408";
		hit=12;
		indirectHit=0;
		indirectHitRange=0;
		airLock=1;
		initSpeed=869;
		typicalSpeed=869;
		airFriction=-0.00047;
		caliber=1.7;
		deflecting=10;
		damageBarrel=500;
		damageBarrelDestroyed=500;
		weight=0.0272;
		impactBehaviour=1;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=472;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=472;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE40mm_HE: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_AE40mm";
		round="FxRound_AE40mm";
		spawnPileType="Ammo_AE40mm_HE";
		hit=0;
		indirectHit=0;
		indirectHitRange=0;
		tracerScale=1;
		caliber=0.0099999998;
		deflecting=5;
		impactBehaviour=1;
		initSpeed=70;
		typicalSpeed=70;
		timeToLive=100;
		airFriction=-0.001;
		supersonicCrackNear[]={};
		supersonicCrackFar[]={};
		weight=0.0149;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{0.5,1}
		};
		class Health
		{
		damage=5;
		};
		class Blood
		{
		damage=0;
		};
		class Shock
		{
		damage=15;
		};
		};
		class NoiseHit
		{
		strength=15;
		type="shot";
		};
	};
	
	class Bullet_AE46x30: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_9mm";
		round="FxRound_9mm";
		spawnPileType="Ammo_AE46x30";
		hit=7;
		indirectHit=0;
		indirectHitRange=0;
		tracerScale=1;
		caliber=0.34999999;
		deflecting=30;
		initSpeed=685;
		typicalSpeed=685;
		airFriction=-0.00303;
		damageBarrel=166.66667;
		damageBarrelDestroyed=166.66667;
		supersonicCrackNear[]={};
		supersonicCrackFar[]={};
		weight=0.0020000001;
		unconRefillModifier=6;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=68;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=68;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE50AE: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_9mm";
		round="FxRound_9mm";
		spawnPileType="Ammo_AE50AE";
		hit=12;
		indirectHit=0;
		indirectHitRange=0;
		tracerScale=1;
		caliber=0.89999998;
		deflecting=10;
		airFriction=-0.0026;
		initSpeed=420;
		typicalSpeed=420;
		damageBarrel=187.5;
		damageBarrelDestroyed=187.5;
		weight=0.019400001;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=123;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=123;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE57x28: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_9mm";
		round="FxRound_9mm";
		spawnPileType="Ammo_AE57x28";
		hit=7;
		indirectHit=0;
		indirectHitRange=0;
		tracerScale=1;
		caliber=0.0044092499;
		deflecting=30;
		initSpeed=715;
		typicalSpeed=715;
		airFriction=-0.0026799999;
		damageBarrel=166.66667;
		damageBarrelDestroyed=166.66667;
		supersonicCrackNear[]={};
		supersonicCrackFar[]={};
		weight=0.0020000001;
		unconRefillModifier=6;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=68;
		armorDamage=2;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=68;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE68x43: Bullet_Base
	{
		scope=2;
		spawnPileType="Ammo_AE68x43";
		casing="FxCartridge_556";
		round="FxRound_556";
		hit=8;
		indirectHit=0;
		indirectHitRange=0;
		initSpeed=785;
		typicalSpeed=785;
		airFriction=-0.00118;
		caliber=0.63999999;
		deflecting=10;
		tracerScale=1;
		tracerStartTime=-1;
		tracerEndTime=1;
		nvgOnly=1;
		damageBarrel=250;
		damageBarrelDestroyed=250;
		weight=0.00745187;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=150;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=150;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE762x25: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_762x39";
		round="FxRound_762x39";
		spawnPileType="Ammo_AE762x25";
		hit=9.5;
		indirectHit=0;
		indirectHitRange=0;
		airLock=1;
		initSpeed=450;
		typicalSpeed=450;
		airFriction=-0.0033;
		caliber=0.89999998;
		deflecting=10;
		damageBarrel=187.5;
		damageBarrelDestroyed=187.5;
		weight=0.0055;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=31;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=31;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE792x33: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_762x39";
		round="FxRound_762x39";
		spawnPileType="Ammo_AE792x33";
		hit=9.5;
		indirectHit=0;
		indirectHitRange=0;
		airLock=1;
		initSpeed=685;
		typicalSpeed=685;
		airFriction=-0.00162;
		caliber=0.69999999;
		deflecting=10;
		damageBarrel=500;
		damageBarrelDestroyed=500;
		weight=0.0081000002;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=96;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=96;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
	class Bullet_AE792x57: Bullet_Base
	{
		scope=2;
		casing="FxCartridge_762";
		round="FxRound_762";
		spawnPileType="Ammo_AE792x57";
		hit=12;
		indirectHit=0;
		indirectHitRange=0;
		airLock=1;
		initSpeed=730;
		typicalSpeed=730;
		airFriction=-0.00082999998;
		caliber=1.1;
		deflecting=10;
		damageBarrel=500;
		damageBarrelDestroyed=500;
		weight=0.0128;
		impactBehaviour=1;
		class DamageApplied
		{
		type="Projectile";
		dispersion=0;
		bleedThreshold=1;
		defaultDamageOverride[]=
		{
		{1,1}
		};
		class Health
		{
		damage=181;
		};
		class Blood
		{
		damage=100;
		};
		class Shock
		{
		damage=181;
		};
		};
		class NoiseHit
		{
		strength=10;
		type="shot";
		};
	};
	
};

class CfgMagazines
{
	class Ammunition_Base;
	
	class Ammo_AE127x99: Ammunition_Base
	{
		scope=2;
		displayName="TEST .50 Cal. BMG Rounds";
		descriptionShort="The .50 Browning Machine Gun (.50 BMG, 12.7×99mm NATO) is a cartridge developed for the Browning Machine Gun, but most notoriously is known for use in the Barrett M82 Anti-Material Rifle.";
		model="AmmunitionExpansion\12.7x99\127x99.p3d";
		iconCartridge=3;
		weight=49;
		count=10;
		ammo="Bullet_AE127x99";
	};
	
	class Ammo_AE300: Ammunition_Base
	{
		scope=2;
		displayName="TEST .300 Blackout Rounds";
		descriptionShort="The .300 AAC Blackout is a carbine cartridge developed in the United States by Advanced Armament Corporation (AAC).";
		model="AmmunitionExpansion\300Blackout\300Blackout.p3d";
		iconCartridge=2;
		weight=7;
		count=20;
		ammo="Bullet_AE300";
	};
	
	class Ammo_AE338: Ammunition_Base
	{
		scope=2;
		displayName="TEST .338 Lapua Magnum Rounds";
		descriptionShort="The .338 Lapua Magnum is a rimless, bottlenecked, centerfire rifle cartridge. It was developed during the 1980s as a high-powered, long-range cartridge for military snipers.";
		model="AmmunitionExpansion\338Lapua\338Lapua.p3d";
		iconCartridge=3;
		weight=16;
		count=20;
		ammo="Bullet_AE338";
	};
	
	class Ammo_AE408: Ammunition_Base
	{
		scope=2;
		displayName="TEST .408 CheyTac Rounds";
		descriptionShort=".408 Cheyenne Tactical, designated .408 CheyTac, is a specialized rimless, bottlenecked, centerfire cartridge for military long-range sniper rifles.";
		model="AmmunitionExpansion\408CheyTac\408CheyTac.p3d";
		iconCartridge=3;
		weight=27;
		count=20;
		ammo="Bullet_AE408";
	};
	
	class Ammo_AE40mm_HE: Ammunition_Base
	{
		scope=2;
		displayName="TEST 40mm HE Grenade";
		descriptionShort="40mm grenade for compatible grenade launchers. This particular one is a high explosive grenade.";
		model="AmmunitionExpansion\40mmGrenade\40mmGrenade.p3d";
		weight=230;
		count=1;
		ammo="Bullet_AE40mm_HE";
	};
	
	class Ammo_AE46x30: Ammunition_Base
	{
		scope=2;
		displayName="TEST 4.6x30mm HK Rounds";
		descriptionShort="The 4.6×30mm HK cartridge is designed to minimize weight and recoil while increasing penetration of body armor. It features a bottlenecked case and a pointed, steel-core, brass-jacketed bullet.";
		model="AmmunitionExpansion\4.6x30HK\46x30HK.p3d";
		iconCartridge=1;
		weight=7;
		count=30;
		ammo="Bullet_AE46x30";
	};
	
	class Ammo_AE50AE: Ammunition_Base
	{
		scope=2;
		displayName="TEST .50 Action Express Rounds";
		descriptionShort="The .50 Action Express is a large-caliber handgun cartridge. Developed in 1988 by American Evan Whildin of Action Arms, the .50 AE is one of the most powerful pistol cartridges in production.";
		model="AmmunitionExpansion\50AE\50AE.p3d";
		iconCartridge=1;
		weight=21;
		count=20;
		ammo="Bullet_AE50AE";
	};
	
	class Ammo_AE57x28: Ammunition_Base
	{
		scope=2;
		displayName="TEST 5.7x28mm FN Rounds";
		descriptionShort="The 5.7×28mm FN is a small-caliber, high-velocity cartridge designed and manufactured by FN Herstal in Belgium.";
		model="AmmunitionExpansion\5.7x28FN\57x28FN.p3d";
		iconCartridge=1;
		weight=6;
		count=30;
		ammo="Bullet_AE57x28";
	};
	
	class Ammo_AE68x43: Ammunition_Base
	{
		scope=2;
		displayName="TEST 6.8x43mm SPC Rounds";
		descriptionShort="The 6.8x43mm Special Purpose Cartridge is a rimless bottlenecked intermediate rifle cartridge that was developed by Remington Arms in collaboration with members of the U.S. Army Marksmanship Unit and United States Special Operations Command to possibly replace the 5.56 NATO cartridge in Short Barreled Rifles and Carbines.";
		model="AmmunitionExpansion\68x43SPC\68x43SPC.p3d";
		iconCartridge=2;
		weight=5;
		count=20;
		ammo="Bullet_AE68x43";
	};
	
	class Ammo_AE762x25: Ammunition_Base
	{
		scope=2;
		displayName="TEST 7.62x25mm Tokarev Rounds";
		descriptionShort="The 7.62×25mm Tokarev cartridge is a Russian rimless bottlenecked pistol cartridge widely used in former Soviet satellite states, and in China and Pakistan among other countries.";
		model="AmmunitionExpansion\7.62x25Tokarev\762x25Tokarev.p3d";
		iconCartridge=1;
		weight=6;
		count=30;
		ammo="Bullet_AE762x25";
	};
	
	class Ammo_AE792x33: Ammunition_Base
	{
		scope=2;
		displayName="TEST 7.92x33mm Kurz Rounds";
		descriptionShort="The 7.92×33mm Kurz is a rimless bottlenecked intermediate rifle cartridge developed in Nazi Germany prior to and during World War II.";
		model="AmmunitionExpansion\7.92x33Kurz\792x33Kurz.p3d";
		iconCartridge=2;
		weight=17;
		count=20;
		ammo="Bullet_AE792x33";
	};
	
	class Ammo_AE792x57: Ammunition_Base
	{
		scope=2;
		displayName="TEST 7.92×57mm Mauser Rounds";
		descriptionShort="The 7.92×57mm Mauser is a rimless bottlenecked rifle cartridge and was the German service cartridge in both World Wars. In its day, the cartridge was one of the world’s most popular military cartridges.";
		model="AmmunitionExpansion\7.92x57Mauser\792x57Mauser.p3d";
		iconCartridge=3;
		weight=13;
		count=20;
		ammo="Bullet_AE792x57";
	};
	
};

class CfgVehicles
{
	class Box_Base;
	
	class AE_AmmoBox_127x99_10rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed .50 Cal. BMG Rounds";
		descriptionShort=".50 Cal. BMG boxed ammunition, 10 rounds.";
		model="DZ\weapons\ammunition\00buck_10roundbox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\12.7x99\data\12.7x99_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=510;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\00buck_box.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\00buck_box.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\00buck_box_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\00buck_box_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\00buck_box_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE127x99
		{
		value=10;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_300_20rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed .300 Blackout Rounds";
		descriptionShort=".300 Blackout boxed ammunition, 20 rounds.";
		model="DZ\weapons\ammunition\556_20roundbox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\300Blackout\data\300Blackout_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=160;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\556_20RoundBox.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\556_20RoundBox.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\556_20RoundBox_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\556_20RoundBox_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\556_20RoundBox_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE300
		{
		value=20;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_338_20rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed .338 Lapua Magnum Rounds";
		descriptionShort=".338 Lapua Magnum boxed ammunition, 20 rounds.";
		model="DZ\weapons\ammunition\762_20roundbox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\338Lapua\data\338Lapua_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=340;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\762_box.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\762_box.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\762_box_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\762_box_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\762_box_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE338
		{
		value=20;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_408_20rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed .408 CheyTac Rounds";
		descriptionShort=".408 CheyTac boxed ammunition, 20 rounds.";
		model="DZ\weapons\ammunition\00buck_10roundbox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\408CheyTac\data\408CheyTac_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=560;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\00buck_box.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\00buck_box.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\00buck_box_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\00buck_box_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\00buck_box_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE408
		{
		value=20;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_46x30_30rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed 4.6x30mm HK Rounds";
		descriptionShort="4.6x30mm HK boxed ammunition, 30 rounds.";
		model="\dz\weapons\ammunition\22_50RoundBox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\4.6x30HK\data\4.6x30HK_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=100;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE46x30
		{
		value=30;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_50AE_20rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed .50 Action Express Rounds";
		descriptionShort=".50 Action Express boxed ammunition, 20 rounds.";
		model="\dz\weapons\ammunition\45ACP_25rnd_box.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\50AE\data\50AE_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=630;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\45cal_box.rvmat"
		}
		},

		{
		0.69999999,
		{}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\45cal_box_damage.rvmat"
		}
		},

		{
		0.30000001,
		{}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\45cal_box_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE50AE
		{
		value=20;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_57x28_30rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed 5.7x28mm FN Rounds";
		descriptionShort="5.7x28mm FN boxed ammunition, 30 rounds.";
		model="\dz\weapons\ammunition\22_50RoundBox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\5.7x28FN\data\5.7x28FN_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=200;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE57x28
		{
		value=30;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_68x43_20rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed 6.8x43mm SPC Rounds";
		descriptionShort="6.8x43mm SPC boxed ammunition, 20 rounds.";
		model="\dz\weapons\ammunition\545x39_20RoundBox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\68x43SPC\data\68x43SPC_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=120;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\545x39box.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\545x39box.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\545x39box_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\545x39box_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\545x39box_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE68x43
		{
		value=20;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_762x25_30rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed 7.62x25mm Tokarev Rounds";
		descriptionShort="7.62x25mm Tokarev boxed ammunition, 30 rounds.";
		model="\dz\weapons\ammunition\22_50RoundBox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\7.62x25Tokarev\data\762x25Tokarev_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=200;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE762x25
		{
		value=30;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_792x33_20rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed 7.92x33mm Kurz Rounds";
		descriptionShort="7.92x33mm Kurz boxed ammunition, 20 rounds.";
		model="\dz\weapons\ammunition\22_50RoundBox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\7.92x33Kurz\data\7.92x33Kurz_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=360;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\22LR_50RoundBox_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE792x33
		{
		value=20;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
	class AE_AmmoBox_792x57_20rnd: Box_Base
	{
		scope=2;
		displayName="TEST Boxed 7.92x57mm Mauser Rounds";
		descriptionShort="7.92×57mm Mauser boxed ammunition, 20 rounds.";
		model="DZ\weapons\ammunition\762_20roundbox.p3d";
		hiddenSelections[]=
		{
		"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
		"AmmunitionExpansion\7.92x57Mauser\data\7.92x57Mauser_box_co.paa"
		};
		rotationFlags=17;
		lootCategory="Ammo";
		weight=280;
		class DamageSystem
		{
		class GlobalHealth
		{
		class Health
		{
		hitpoints=100;
		healthLevels[]=
		{

		{
		1,

		{
		"DZ\weapons\ammunition\data\762_box.rvmat"
		}
		},

		{
		0.69999999,

		{
		"DZ\weapons\ammunition\data\762_box.rvmat"
		}
		},

		{
		0.5,

		{
		"DZ\weapons\ammunition\data\762_box_damage.rvmat"
		}
		},

		{
		0.30000001,

		{
		"DZ\weapons\ammunition\data\762_box_damage.rvmat"
		}
		},

		{
		0,

		{
		"DZ\weapons\ammunition\data\762_box_destruct.rvmat"
		}
		}
		};
		};
		};
		};
		class Resources
		{
		class Ammo_AE792x57
		{
		value=20;
		variable="quantity";
		};
		};
		class AnimEvents
		{
		class SoundWeapon
		{
		class interact
		{
		soundset="ammoboxUnpack_SoundSet";
		id=70;
		};
		};
		};
	};
	
};
